# {{classname}}

All URIs are relative to *https://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**HeroGet**](DefaultApi.md#HeroGet) | **Get** /hero | 
[**HeroHeroIDDelete**](DefaultApi.md#HeroHeroIDDelete) | **Delete** /hero/{heroID} | 
[**HeroHeroIDGet**](DefaultApi.md#HeroHeroIDGet) | **Get** /hero/{heroID} | 
[**HeroHeroIDPut**](DefaultApi.md#HeroHeroIDPut) | **Put** /hero/{heroID} | 
[**HeroPost**](DefaultApi.md#HeroPost) | **Post** /hero | 

# **HeroGet**
> []Hero HeroGet(ctx, optional)


Get all heroes

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***DefaultApiHeroGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a DefaultApiHeroGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **namaHero** | **optional.String**|  | 

### Return type

[**[]Hero**](Hero.md)

### Authorization

[HeroAuth](../README.md#HeroAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **HeroHeroIDDelete**
> InlineResponse200 HeroHeroIDDelete(ctx, heroID)


Delete Hero

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **heroID** | **int32**| Hero ID | 

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

[HeroAuth](../README.md#HeroAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **HeroHeroIDGet**
> Hero HeroHeroIDGet(ctx, heroID)


Get Hero by ID

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **heroID** | **int32**| Hero ID | 

### Return type

[**Hero**](Hero.md)

### Authorization

[HeroAuth](../README.md#HeroAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **HeroHeroIDPut**
> Hero HeroHeroIDPut(ctx, body, heroID)


### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**HeroInput**](HeroInput.md)|  | 
  **heroID** | **int32**| Hero ID | 

### Return type

[**Hero**](Hero.md)

### Authorization

[HeroAuth](../README.md#HeroAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **HeroPost**
> Hero HeroPost(ctx, body)


Create a new hero

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**HeroInput**](HeroInput.md)|  | 

### Return type

[**Hero**](Hero.md)

### Authorization

[HeroAuth](../README.md#HeroAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

